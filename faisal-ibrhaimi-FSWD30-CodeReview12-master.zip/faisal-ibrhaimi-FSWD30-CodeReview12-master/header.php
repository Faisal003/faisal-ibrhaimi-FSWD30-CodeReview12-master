<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CARS
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<nav class="navbar navbar-default" id="navbar">
	  	<div class="container-fluid">
	    	<div class="navbar-header"><!--Now we want the navbar to be like buttom when we let the width of our page small  -->
	      		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="	#bs-example-navbar-collapse-1" aria-expanded="false">
	        		<span class="sr-only">Toggle navigation</span>
	        		<span class="glyphicon glyphicon-menu-hamburger"></span>
	      		</button>
	      		<a class="navbar-brand" href="#"><img src="" class="brand" width="35" height="35"></a>
	    	</div>
	    	
	    <!-- Collect the nav links, forms, and other content for toggling -->
	    	<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	      		<ul class="nav navbar-nav" id="nav-menu">
		    		<li><a href="http://localhost/ghiathserri_wp/" class="navbar-brand">Home</a></li>
	      			<li><a href="http://localhost/ghiathserri_wp/activity/"  class="navbar-brand">Activity</a></li>
	      			<li><a href="http://localhost/ghiathserri_wp/members"  class="navbar-brand">Members</a></li>
	      			<li><a href="http://localhost/ghiathserri_wp/sample-page"  class="navbar-brand">sample-page</a></li>
					<li class="dropdown">
				        <a class="dropdown-toggle navbar-brand" data-toggle="dropdown" href="#" >Menu
				        	<span class="caret"></span>
				        </a>
				        <ul class="dropdown-menu" id="dropdown">
				          <?php
		           			wp_nav_menu( array(
		           			    'menu'              => 'primary',
		           			    'theme_location'    => 'primary',
		           			    'depth'             => 2,
		           			    'container'         => 'div',
		           			    'container_class'   => 'collapse navbar-collapse',
		           			    'container_id'      => 'bs-example-navbar-collapse-1',
		           			    'menu_class'        => 'nav navbar-nav',
		           			    'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
		           			    'walker'            => new WP_Bootstrap_Navwalker())
		           				);
		       			?><!--Here we make a navbar-->
				        </ul>
		      		</li>
      			</ul>
	      		<ul class="nav navbar-nav navbar-right">
	      			<li>
	            		<fb:login-button
	              			style="margin-top: 17px;"
	              			id = "fb_btn"
	              			scope="public_profile,email" 
	              			onlogin="checkLoginState();">
	            		</fb:login-button>
	          		</li>

	  <!-- <a id="fb_logout" href="#">Log Out</a> -->
	            	<button id="fb_logout" class="btn btn-danger btn-xs" onclick="logout()" style="margin-top: 17px;">Log Out
	            	</button>
	            	<br>
	      		</ul>
	    	</div><!-- /.navbar-collapse -->
	  	</div><!-- /.container-fluid -->
	</nav>
		<div id="jumbotron">
			<h1 class="text-center hero-text">Mount Everest</h1>
		</div>
		<div id="status" style="margin-top: 75px;"></div>
		<br>
		<div class="container">
		<div class="row">
			<div class="col-md-4 col-sm-4 col-xs-12">
				<img src="http://www.icacie.com/2016/wp-content/uploads/airplane.gif" width="250" style="margin-left: 50px;">
				<h4 class="text-center" style="margin-top: 30px;">Travelers are urged to enroll in the Smart Traveler Enrollment Program(STEP) to receive security messages and make it easier to locate you in an emergency.</h4>
			</div>
			<div class="col-md-4 col-sm-4 col-xs-12">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSR4fnGS1jMq-Hqz68UP73YNoiR3c4R6w93V1dsql4KMXqXDHavxg" width="250" style="margin-left: 50px;">
				<h4 class="text-center" style="margin-top: 10px;">How To Save Money For Travel. After countless emails from readers asking about how I'm able to travel the world constantly, I wanted to share some useful tips about how I learned to save money for traveling. </h4>
			</div>
			<div class="col-md-4 col-sm-4 col-xs-12">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQy1jEpskxfrqaRY1X_EtYLM1mKFsjxVgkAGOCubG1_X27l8tt3" width="250" style="margin-top: 45px;margin-left: 50px;">
				<h4 class="text-center" style="margin-top: 50px;">Make The Best Of Your Travel To USA, Get Inspired With Our Insider's Guide Now!
Explore USA · Travel Ideas & Tips · USA Trip Planner ·</h4>
			</div>
		</div>
	</div>
	<hr>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'cars' ); ?></a>
	

	<div id="content" class="site-content">
