<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CARS
 */

?>

	</div><!-- #content -->
	<div class="parallax2" style="margin-top: 30px;"></div>
	<div class="container wow zoomIn" style="width: 80%;margin-top: 50px;margin-bottom: 30px; ">
		<div class="row">
			<div class="col-md-3 col-sm-6">
				<a href="#">
					<img src="https://image.freepik.com/free-icon/facebook-logo-with-rounded-corners_318-9850.jpg" width="100" style="margin-left: 70px;">
				</a>
				<h3 class="text-center">FaceBook</h3>
			</div>
			<div class="col-md-3 col-sm-6">
				<a href="#">
					<img src="https://image.freepik.com/free-icon/twitter-logo_318-40459.jpg" width="100" style="margin-left: 70px;">
				</a>
				<h3 class="text-center">Twitter</h3>
			</div>
			<div class="col-md-3 col-sm-6">
				<a href="#">
					<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSyJLYp0nSyZHNQv4qt5uVM0G3O7J37-0IjHV2Xpyobs6AG5juI-A" width="100" style="margin-left: 70px;">
				</a>
				<h3 class="text-center">GitHub</h3>
			</div>
			<div class="col-md-3 col-sm-6">
				<div id="myCarousel" class="carousel slide" data-ride="carousel">
          <!-- Indicators -->
          <!-- Wrapper for slides -->
          <div class="carousel-inner">
            <div class="item active">
              <img src="http://veva.cz/upload/images/first-mountain-trip.jpg" alt="Los Angeles" width="100%" style="height: 160px;">
            </div>

            <div class="item">
              <img src="https://mountaintrip.com/wp-content/uploads/2013/10/CO-page-_6.jpg" alt="Chicago" width="100%" style="height: 160px;">
            </div>
          
            <div class="item">
              <img src="https://www.rei.com/adventures/assets/adventures/images/trip/core/europe/tmb_hero" alt="New york" width="100%" style="height: 160px;">
            </div>
          </div>

          <!-- Left and right controls -->
          <a class="left carousel-control" href="#myCarousel" data-slide="prev">
          </a>
          <a class="right carousel-control" href="#myCarousel" data-slide="next">
          </a>
        </div>
			</div>
		</div>
	</div>
	<footer class="blog-footer text-center jumbotron">
     	<h4> &copy; <?php echo Date('Y'); ?> - <?php bloginfo('name'); ?></h4>
     	<h4>
       		<a href="#">Back to top</a>
     	</h4>
   </footer>
   <?php wp_footer(); ?>
</div><!-- #page -->

<?php wp_footer(); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$(".thumbnail").on("mouseover",function(){
			$(this).css("box-shadow","1px 1px 15px black");
		});
		$(".thumbnail").on("mouseout",function(){
			$(this).css("box-shadow","");
		})
	})
</script>
<script>

    window.fbAsyncInit = function() {
      FB.init({
        appId      : '153480088689158',
        cookie     : true,
        xfbml      : true,
        version    : 'v2.12'
      });
        
      // FB.AppEvents.logPageView();   
      FB.getLoginStatus(function(response) {
          statusChangeCallback(response);
      });
        
    };

    (function(d, s, id){
       var js, fjs = d.getElementsByTagName(s)[0];
       if (d.getElementById(id)) {return;}
       js = d.createElement(s); js.id = id;
       js.src = "https://connect.facebook.net/en_US/sdk.js";
       fjs.parentNode.insertBefore(js, fjs);
     }(document, 'script', 'facebook-jssdk'));


    function statusChangeCallback(response) {
      if(response.status === "connected") {
        console.log("logged in and authentificated");
        hideShowElements(true);
        testAPI();

      } 
      else {
        console.log("not authentificated");
        document.getElementById('status').innerHTML = '';
        hideShowElements(false);
      }
    }

    function checkLoginState() {
      FB.getLoginStatus(function(response) {
        statusChangeCallback(response);
      });
    }

    function testAPI(){

      console.log('Welcome!  Fetching your information.... ');

      FB.api('me?fields=id,name,email', function(response){
        if(response && !response.error) {
          console.log(response);
          document.getElementById('status').innerHTML =
            "<h1 class='text-center text-success'>Thanks for logging in, " + response.name + '!</h1>';
        } else {
          console.log('first-method - User cancelled login or did not fully authorize.');
        }
      });


      FB.login(function(response) {
          if (response.authResponse) {
           FB.api('me?fields=id,name,email', function(response) {
             document.getElementById('status').innerHTML += "<h3 class='text-center'>Good to see you, " + response.name + '.</h3>';
           });
          } else {
           console.log('User cancelled login or did not fully authorize.');
          }
      });
    }

      function logout () {
        FB.logout(function(response) {
          statusChangeCallback(response);
        });
        }

    function hideShowElements (isLoggedIn){
      if (isLoggedIn) {
        document.getElementById("fb_logout").style.display ="block";
        document.getElementById("fb_btn").style.display ="none";
      
      } else {
        document.getElementById("fb_logout").style.display ="none";
        document.getElementById("fb_btn").style.display ="block";
      
      }
    }
  </script>
</body>
</html>
